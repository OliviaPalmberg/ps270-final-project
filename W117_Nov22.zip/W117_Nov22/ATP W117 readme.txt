PEW RESEARCH CENTER
Wave 117 American Trends Panel 
Dates: Nov. 16, 2022 - Nov. 27, 2022
Mode: Web 
Sample: Full panel
Language: English and Spanish
N=11,377 

***************************************************************************************************************************

NOTES

On October 31, 2024 10 new variables were added to the dataset to provide users with the ability to identify validated voters for the 2022, 2020, 2018 and 2016 general elections, along with presidential vote choice in 2020 and 2016 and vote for the U.S. House of Representatives for 2022 and 2018. Two special weights variable have been added and should be used with any analysis involving validated voters and nonvoters. These were used in the production of the report “Republican Gains in 2022 Midterms Driven Mostly by Turnout Advantage” found at https://www.pewresearch.org/politics/2023/07/12/republican-gains-in-2022-midterms-driven-mostly-by-turnout-advantage/.
The two new weight variables are:
WEIGHT_W117_VALIDATEDVOTE
This weight should be used in conjunction with any analysis involving validated voters in the 2022 election alone.
WEIGHT_W78_W117_VALIDATEDVOTE
This weight should be used in conjunction with any analysis that combines the voter turnout or vote choice variables from multiple elections in this dataset.
Details about the creation of these variables and how to use them can be found in this essay: https://www.pewresearch.org/decoded/validating-2022-voters-in-pew-research-centers-survey-data/ 
The new turnout variables are:
VOTED2022	Validated turnout in 2022 general election
VOTED2020	Validated turnout in 2020 general election
VOTED2018	Validated turnout in 2018 general election
VOTED2016	Validated turnout in 2016 general election
The new vote choice variables are:
VOTECHOICE2022	Vote choice for U.S. House of Representatives in 2022 among validated voters
VOTECHOICE2020	Vote choice for president in 2020 among validated voters
VOTECHOICE2018	Vote choice for U.S. House of Representatives in 2018 among validated voters
VOTECHOICE2016	Vote choice for president in 2016 among validated voters

For a small number of respondents with high risk of identification, certain values have been randomly swapped with those of lower risk cases with similar characteristics.

PREFWHY1_W117/WATCHREAS_W117
The W117 dataset contains the following coded open-end responses to PREFWHY1_W117 and WATCHREAS_W117. Up to three mentions were coded for each open end.
PREFWHY1_OE1_W117
PREFWHY1_OE2_W117
PREFWHY1_OE3_W117
WATCHREAS_OE1_W117
WATCHREAS_OE2_W117
WATCHREAS_OE3_W117

W117 included questions used in a longitudinal analysis in the report, "How the Pandemic Has Affected Attendance at U.S. Religious Services." If you would like to replicate the longitudinal analysis in this report, please contact us. 

***************************************************************************************************************************
WEIGHTS 

There are four weights in the W117 dataset

WEIGHT_W117 is the weight for the sample. Data for most Pew Research Center reports are analyzed using this weight.
WEIGHT_W117_VOTE is a special weight that includes a benchmark for turnout and the popular vote margin. This weight should be used to replicate findings from the report, "Public Has Modest Expectations for Washington’s Return to Divided Government"
WEIGHT_W117_VALIDATEDVOTE
This weight should be used in conjunction with any analysis involving validated voters in the 2022 election alone.
WEIGHT_W78_W117_VALIDATEDVOTE
This weight should be used in conjunction with any analysis that combines the voter turnout or vote choice variables from multiple elections in this dataset.

***************************************************************************************************************************
Releases from this survey:

December 1, 2022 "Public Has Modest Expectations for Washington’s Return to Divided Government"
https://www.pewresearch.org/politics/2022/12/01/public-has-modest-expectations-for-washingtons-return-to-divided-government/#:~:text=Americans%20largely%20expect%20the%20partisan,improve%20in%20the%20next%20year.   

March 28, 2023 "How the Pandemic Has Affected Attendance at U.S. Religious Services"
https://www.pewresearch.org/religion/2023/03/28/how-the-pandemic-has-affected-attendance-at-u-s-religious-services/

June 2, 2023 "Online Religious Services Appeal to Many Americans, but Going in Person Remains More Popular"
https://www.pewresearch.org/religion/2023/06/02/online-religious-services-appeal-to-many-americans-but-going-in-person-remains-more-popular/

September 6, 2023 "Why some Americans prefer to go to religious services in person and others prefer to watch virtually" 
https://www.pewresearch.org/short-reads/2023/09/06/why-some-americans-prefer-to-go-to-religious-services-in-person-and-others-prefer-to-watch-virtually/
“Republican Gains in 2022 Midterms Driven Mostly by Turnout Advantage” 
https://www.pewresearch.org/politics/2023/07/12/republican-gains-in-2022-midterms-driven-mostly-by-turnout-advantage/
